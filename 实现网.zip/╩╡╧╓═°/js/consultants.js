var famous_company = ["360", "58", "36\u6c2a", "58\u8d76\u96c6", "178", "51\u4fe1\u7528\u5361", "91\u52a9\u624b", "1\u53f7\u5e97", "\u963f\u91cc", "\u7231\u5947\u827a", "AcFun", "\u7231\u7acb\u4fe1", "\u767e\u5ea6", "\u767e\u5ea6\u7cef\u7c73", "\u767e\u5ea6\u5728\u7ebf", "\u767e\u5ea6\u5916\u5356", "\u767e\u5ea691", "\u66b4\u98ce\u5f71\u97f3", "\u66b4\u98ce\u9b54\u955c", "\u66b4\u98ce\u79d1\u6280", "\u660e\u57fa", "\u535a\u5f66", "\u535a\u5f66\u79d1\u6280", "Bilibili", "\u535a\u6717", "\u521b\u4e1a", "\u521b\u65b0\u5de5\u573a", "\u957f\u8679", "\u89e6\u63a7\u79d1\u6280", "\u9524\u5b50", "\u9524\u5b50\u79d1\u6280", "CSDN", "\u6ef4\u6ef4", "\u8c46\u74e3", "\u70b9\u8bc4", "\u5927\u4f17\u70b9\u8bc4", "\u5f53\u5f53\u7f51", "\u4e1c\u8f6f", "\u5927\u5510", "\u5f53\u5f53", "\u5927\u9ea6\u7f51", "\u8c46\u679c\u7f8e\u98df", "DELL", "\u997f\u4e86\u4e48", "ebay", "fir.im", "\u98ce\u884c\u7f51", "\u51e1\u5ba2", "\u65b9\u6b63", "\u51e4\u51f0\u7f51", "\u5bcc\u58eb\u5eb7", "\u98de\u4fe1", "\u5206\u671f\u4e50", "\u51e1\u5ba2", "\u56fd\u7f8e", "\u56fd\u7f8e\u5728\u7ebf", "\u8c37\u6b4c", "Google", "\u9ad8\u5fb7", "\u9ad8\u5fb7\u4f53\u80b2", "\u9ad8\u5fb7\u5730\u56fe", "\u8d76\u96c6", "\u9ad8\u901a", "\u60e0\u666e\u4e2d\u56fd", "\u60e0\u666e", "HP", "\u534e\u4e3a", "hao123", "\u597d\u672a\u6765", "\u73af\u4fe1", "\u6d77\u5c14\u96c6\u56e2", "H3C", "\u864e\u6251", "\u534e\u6cf0\u8bc1\u5238", "IBM", "IBM\u7814\u53d1\u4e2d\u5fc3", "\u4eac\u4e1c", "\u4eac\u4e1c\u5230\u5bb6", "\u4eac\u4e1c\u91d1\u878d", "\u91d1\u5c71", "\u91d1\u5c71\u6bd2\u9738", "\u805a\u7f8e\u4f18\u54c1", "\u673a\u950b", "\u673a\u950b\u7f51", "\u9152\u4ed9\u7f51", "\u91d1\u8776", "\u6781\u5ba2\u516c\u56ed", "\u4eca\u65e5\u5934\u6761", "\u501f\u8d37\u5b9d", "\u4f73\u80fd", "\u4f73\u80fd\u4e2d\u56fd", "\u9177\u72d7", "\u9177\u6211\u97f3\u4e50", "\u9177\u6211", "\u5feb\u64ad", "\u5f00\u6e90\u4e2d\u56fd", "\u79d1\u5927\u8baf\u98de", "\u730e\u8c79", "\u730e\u8c79\u79fb\u52a8", "\u4e50\u89c6", "\u793c\u7269\u8bf4", "\u8054\u60f3", "\u8054\u60f3\u7814\u7a76\u9662", "\u62c9\u52fe", "\u94fe\u5bb6", "\u84dd\u8272\u5149\u6807", "\u5170\u4ead\u96c6\u52bf", "\u730e\u8058", "\u8354\u679dFM", "LINE", "\u8054\u53d1\u79d1", "LinkedIn", "\u7eff\u76df", "\u4e50\u89c6\u5f71\u4e1a", "\u7f8e\u56e2", "\u7f8e\u4e3d\u8bf4", "\u8611\u83c7\u8857", "\u8682\u8702\u7a9d", "\u9762\u5305\u65c5\u884c", "\u964c\u964c", "\u58a8\u8ff9\u5929\u6c14", "\u9b45\u65cf", "\u79d2\u62cd", "nice", "NEC", "OPPO", "Oracle", "OneAPM", "\u50b2\u6e38", "\u82f9\u679c", "Apple", "\u5e73\u5b89", "pptv", "\u6c7d\u8f66\u4e4b\u5bb6", "\u9a71\u52a8\u4eba\u751f", "\u7cd7\u767e", "\u4eba\u4eba\u7f51", "\u4eba\u4eba\u6e38\u620f", "\u5b9e\u73b0\u7f51", "\u76db\u5927\u6e38\u620f", "\u76db\u5927", "\u641c\u72d0", "\u641c\u72d0\u89c6\u9891", "\u641c\u72d0\u7545\u6e38", "\u641c\u72d7", "\u641c\u623f", "\u4e09\u661f", "\u4e09\u661f\u7535\u5b50", "\u4e09\u661f\u4e2d\u56fd", "\u4e16\u7eaa\u4f73\u7f18", "\u795e\u5dde\u6570\u7801", "\u89c6\u89c9\u4e2d\u56fd", "\u82cf\u5b81\u96c6\u56e2", "\u82cf\u5b81", "\u82cf\u5b81\u6613\u8d2d", "\u677e\u4e0b", "\u987a\u4e30", "SAP", "\u601d\u79d1", "\u817e\u8baf", "\u6dd8\u5b9d", "\u9014\u725b", "\u592a\u5e73\u6d0b\u7f51\u7edc", "Thoughtworks", "\u5929\u732b", "\u5929\u6daf\u793e\u533a", "\u9014\u6e38", "TP-LINK", "TCL", "\u5929\u661f\u8d44\u672c", "Uber", "UBER", "UC", "vivo", "\u5fae\u535a", "\u5fae\u8f6f\u4e2d\u56fd", "\u5fae\u8f6f\u79fb\u52a8", "Microsoft", "\u5fae\u8f6f", "\u7f51\u6613", "\u7f51\u6613\u6709\u9053", "\u7f51\u6613\u6e38\u620f", "\u5b8c\u7f8e\u4e16\u754c", "\u7f51\u79e6", "\u552f\u54c1\u4f1a", "\u6211\u7231\u6211\u5bb6", "\u4e4c\u4e91", "\u77e5\u9053\u521b\u5b87", "\u4e07\u8fbe", "\u4e07\u8fbe\u7535\u5546", "\u7a9d\u7a9d\u56e2", "\u8c4c\u8c46\u835a", "\u7f51\u9f99", "\u65b0\u6d6a\u5fae\u535a", "\u65b0\u6d6a\u4e50\u5c45", "\u65b0\u6d6a\u6e38\u620f", "\u65b0\u6d6a", "\u5c0f\u7c73", "\u65b0\u4e1c\u65b9", "\u643a\u7a0b", "\u8fc5\u96f7", "\u5c0f\u7ea2\u4e66", "\u5b66\u800c\u601d", "\u897f\u95e8\u5b50", "\u718a\u732bTV", "\u559c\u9a6c\u62c9\u96c5", "\u8bb8\u9c9c\u7f51", "\u4f18\u6b65", "\u4f18\u9177\u571f\u8c46", "\u4f18\u9177", "\u827a\u9f99", "\u7528\u53cb", "\u733f\u9898\u5e93", "\u97f3\u60a6\u53f0", "\u5b9c\u4eba\u8d37", "\u6613\u8f66", "\u6709\u7f18\u7f51", "YY", "\u79fb\u52a8", "\u6709\u8d5e", "\u82f1\u7279\u5c14", "\u652f\u4ed8\u5b9d", "\u53bb\u54ea\u513f", "\u8054\u901a", "\u667a\u8054", "\u4e2d\u79d1\u8f6f", "\u4e2d\u5174", "\u77e5\u4e4e", "\u638c\u9605\u79d1\u6280", "\u638c\u9605", "\u73cd\u7231", "\u4e2d\u56fd\u79fb\u52a8", "\u4e2d\u641c", "\u4e2d\u56fd\u7535\u4fe1", "\u4e2d\u56fd\u79fb\u52a8\u7814\u7a76\u9662"],
    famous_company_color_undefine = ["#04AECC", "#049D8D", "#0496AC"],
    famous_company_colors = {
        360: "#17b653",
        58: "#ff7200",
        Uber: "#22636B",
        UBER: "#22636B",
        "\u65b0\u6d6a": "#e6172c",
        "\u5fae\u535a": "#e6172c",
        "\u817e\u8baf": "#007ddc",
        "\u767e\u5ea6": "#2418dc",
        "\u963f\u91cc": "#ff6b01",
        "\u6dd8\u5b9d": "#ff6b01",
        "\u652f\u4ed8\u5b9d": "#01a9ef",
        "\u60e0\u666e": "#01a9ef",
        "\u60e0\u666e\u4e2d\u56fd": "#01a9ef",
        "\u5c0f\u7c73": "#ef8300",
        "\u6ef4\u6ef4": "#fea70d",
        "\u53bb\u54ea\u513f": "#00a9be",
        "\u641c\u72d0": "#fe0000",
        IBM: "#1756c4",
        "\u9ad8\u5fb7": "#01aceb",
        "\u9ad8\u5fb7\u5730\u56fe": "#01aceb",
        "\u4eac\u4e1c": "#b70000",
        "\u805a\u7f8e\u4f18\u54c1": "#ee145b",
        "\u62c9\u52fe": "#06b987",
        "\u8054\u60f3": "#dc0808",
        "\u65b9\u6b63": "#f05a30",
        "\u77e5\u4e4e": "#0b61ef"
    },
    pre_replace = {
        "sina weibo": "\u65b0\u6d6a\u5fae\u535a",
        "\u5317\u4eac\u4e2d\u79d1\u9662\u8f6f\u4ef6\u4e2d\u5fc3": "\u4e2d\u79d1\u8f6f",
        "\u5317\u4eac\u5206\u516c\u53f8": "",
        "PP \u79df\u8f66": "PP\u79df\u8f66"
    },
    famous_company_map = {
        "\u5317\u4eac\u65b0\u6d6a\u5fae\u535a": "\u5fae\u535a",
        "\u65b0\u6d6a\u5fae\u535a": "\u5fae\u535a",
        "\u65b0\u6d6a\u7f51": "\u65b0\u6d6a",
        "\u5947\u864e360(|\u79d1\u6280)": "360",
        "Uber\uff08\u4f18\u6b65\uff09": "Uber",
        "(\u4eba\u6c11)\u4f18\u6b65": "Uber",
        "\u7f8e\u56e2(\u7f51)": "\u7f8e\u56e2",
        "\u6ef4\u6ef4(\u51fa\u884c|\u6253\u8f66)": "\u6ef4\u6ef4",
        "\u963f\u91cc(\u5988\u5988|\u7238\u7238|\u5df4\u5df4)": "\u963f\u91cc",
        "(alibaba|ali|Ali|Alibaba)": "\u963f\u91cc",
        "\u5c0f\u7c73\u79d1\u6280": "\u5c0f\u7c73",
        "(\u8682\u8681\u91d1\u670d|alipay|\u8682\u8681\u91d1\u670d(\u652f\u4ed8\u5b9d))": "\u652f\u4ed8\u5b9d",
        "\u65b0\u6d6a(\u7f51|\u65e0\u7ebf)": "\u65b0\u6d6a",
        "(sina|Sina|SINA|sina\u65b0\u6d6a)": "\u65b0\u6d6a",
        "(58|\u4e94\u516b)(\u5230\u5bb6|\u540c\u57ce|\u96c6\u56e2|.com)": "58",
        "\u6dd8\u5b9d\u7f51": "\u6dd8\u5b9d",
        "\u4eac\u4e1c(\u7f51|\u5546\u57ce)": "\u4eac\u4e1c",
        "\u827a\u9f99(\u7f51|\u65c5\u884c|\u65c5\u884c\u7f51)": "\u827a\u9f99",
        "\u4f18\u9177\u571f\u8c46\u96c6\u56e2": "\u4f18\u9177\u571f\u8c46",
        "\u5927\u4f17\u70b9\u8bc4\u7f51": "\u5927\u4f17\u70b9\u8bc4",
        "\u4e50\u89c6\u7f51": "\u4e50\u89c6",
        "(qunar|Qunar-\u53bb\u54ea\u513f\u7f51|\u53bb\u54ea\u513f\u7f51)": "\u53bb\u54ea\u513f",
        "\u641c\u623f\u7f51": "\u641c\u623f",
        "\u4e2d\u56fd\u8054\u901a": "\u8054\u901a",
        "\u91d1\u5c71(\u8f6f\u4ef6|\u4e91|\u529e\u516c\u8f6f\u4ef6|kingsoft)": "\u91d1\u5c71",
        "\u4eba\u4eba": "\u4eba\u4eba\u7f51",
        "\u641c\u72d0\u96c6\u56e2": "\u641c\u72d0",
        "\u8d76\u96c6\u7f51": "\u8d76\u96c6",
        "(Tencent|tencent|\u817e\u8baf\u79d1\u6280|\u817e\u8baf\u516c\u53f8|\u817e\u8baf\u96c6\u56e2|\u9e45\u5382)": "\u817e\u8baf",
        "\u76db\u5927\u7f51\u7edc": "\u76db\u5927",
        "\u667a\u8054\u62db\u8058": "\u667a\u8054",
        "\u964c\u964c\u79d1\u6280": "\u964c\u964c",
        "(\u9014\u725b\u65c5\u884c\u7f51|\u5357\u4eac\u9014\u725b)": "\u9014\u725b",
        "\u94fe\u5bb6\u7f51": "\u94fe\u5bb6",
        "\u65b0\u4e1c\u65b9(\u5728\u7ebf|\u6559\u80b2\u79d1\u6280\u96c6\u56e2)": "\u65b0\u4e1c\u65b9",
        "\u62c9\u52fe\u7f51": "\u62c9\u52fe",
        "\u7528\u53cb(\u7f51\u7edc|\u8f6f\u4ef6)": "\u7528\u53cb",
        "\u730e\u8058\u7f51": "\u730e\u8058",
        "\u65b9\u6b63(\u79d1\u6280|\u96c6\u56e2)": "\u65b9\u6b63",
        "(ZTE|\u4e2d\u5174\u901a\u8baf)": "\u4e2d\u5174",
        "\u8054\u60f3(\u96c6\u56e2|\uff08\u5317\u4eac\uff09)": "\u8054\u60f3",
        "\u643a\u7a0b(\u79d1\u6280|\u7f51|\u65c5\u884c\u7f51)": "\u643a\u7a0b",
        youku: "\u4f18\u9177",
        "\u9177\u72d7\u97f3\u4e50": "\u9177\u72d7",
        "(acfun|Acfun)": "AcFun",
        Qualcomm: "\u9ad8\u901a",
        Elong: "\u827a\u9f99",
        "\u7f51\u79e6\u79d1\u6280": "\u7f51\u79e6",
        "\u5317\u4eac\u730e\u8c79\u79fb\u52a8": "\u730e\u8c79\u79fb\u52a8",
        yy: "YY",
        "(huawei|\u534e\u4e3a\u79d1\u6280)": "\u534e\u4e3a",
        "(\u7532\u9aa8\u6587Oracle|\u7532\u9aa8\u6587)": "Oracle",
        oppo: "OPPO",
        eleme: "\u997f\u4e86\u4e48",
        "(\u963f\u91ccUC|UC\u4f18\u89c6\u79d1\u6280)": "UC",
        "\u9b45\u65cf\u79d1\u6280": "\u9b45\u65cf",
        "\u987a\u4e30\u901f\u8fd0": "\u987a\u4e30",
        "\u5feb\u64ad\u79d1\u6280": "\u5feb\u64ad",
        "(Baidu|baidu|\u67d0\u5ea6|\u718a\u5382)": "\u767e\u5ea6",
        "\u67d0\u6613": "\u7f51\u6613",
        "\u6613\u8f66\u7f51": "\u6613\u8f66",
        "\u5fae\u8f6f(\u4e9a\u6d32\u7814\u7a76\u9662|\u4e9a\u6d32\u4e92\u8054\u7f51\u5de5\u7a0b\u9662|\u4e2d\u56fd)": "\u5fae\u8f6f",
        "(TP-Link|TP-LINK\u666e\u8054|\u666e\u8054)": "TP-LINK",
        ibm: "IBM",
        "(intel|Intel|INTEL)": "\u82f1\u7279\u5c14",
        "\u5927\u5510\u7535\u4fe1": "\u5927\u5510",
        "(sap|Sap)": "SAP",
        "\u5e7f\u5dde\u552f\u54c1\u4f1a": "\u552f\u54c1\u4f1a",
        "(Dell|\u6234\u5c14)": "DELL",
        "(cisco|\u601d\u79d1\u516c\u53f8)": "\u601d\u79d1",
        "\u7cd7\u4e8b\u767e\u79d1": "\u7cd7\u767e",
        oneapm: "OneAPM",
        "\u597d\u672a\u6765\u96c6\u56e2": "\u597d\u672a\u6765",
        "\u50b2\u6e38\u6d4f\u89c8\u5668": "\u50b2\u6e38",
        "(\u767e\u5ea6\u65e0\u7ebf91|\u767e\u5ea691|\u767e\u5ea691\u65e0\u7ebf|91\u624b\u673a\u52a9\u624b)": "91\u52a9\u624b",
        "\u91d1\u8776\u8f6f\u4ef6": "\u91d1\u8776",
        "36kr": "36\u6c2a",
        "\u732a\u516b\u6212\u7f51": "\u732a\u516b\u6212"
    },
    Company = function () {
        this.is_famous = function (a) {
            return -1 < $.inArray(a, famous_company)
        }, this.hash_code = function (a) {
            var n, e, o = 0;
            if (0 === a.length) return o;
            for (n = 0, e = a.length; n < e; n++) o = (o << 5) - o + a.charCodeAt(n), o |= 0;
            return o
        }, this.tiny = function (a) {
            var n = a.replace(/(\u80a1\u4efd\u6709\u9650\u516c\u53f8|\u6709\u9650\u8d23\u4efb\u516c\u53f8|\u8d23\u4efb\u6709\u9650\u516c\u53f8|\u7f51\u7edc\u6709\u9650\u516c\u53f8|\u7f51\u7edc\u79d1\u6280\u6709\u9650\u516c\u53f8|\u6709\u9650\u516c\u53f8|\u79d1\u6280\u80a1\u4efd\u6709\u9650\u516c\u53f8|\u79d1\u6280\u6709\u9650\u516c\u53f8)/g, "");
            for (var e in n = n.trim(), famous_company_map) {
                var o = new RegExp(e),
                    i = n.match(o);
                if (null != i && 0 < i.length) {
                    n = famous_company_map[e];
                    break
                }
            }
            return n
        }, this.match_color = function (a) {
            return color = famous_company_colors[a], color || famous_company_color_undefine[Math.abs(this.hash_code(a)) % famous_company_color_undefine.length]
        }, this.famous_color = function (a) {
            return this.is_famous(a) ? this.match_color(a) : null
        }, this.famous_companys = function (a) {
            for (var n in pre_replace) a = a.replace(n, pre_replace[n]);
            for (var e = a.trim().replace(/[,\|\uff0c \u3001\uff1b\uff0f\/&]/g, " ").replace(/  /g, " ").split(" "), o = [], i = 0; i < e.length; i++) {
                if (a = this.tiny(e[i])) {
                    var t = this.famous_color(a);
                    null != t ? o.push({
                        is_famous: !0,
                        company_name: a,
                        company_color: t,
                        company_border_color: t
                    }) : o.push({
                        is_famous: !1,
                        company_name: a,
                        company_color: "#333",
                        company_border_color: "none"
                    })
                }
            }
            return o.sort(function (a, n) {
                var e = n.is_famous,
                    o = a.is_famous;
                return e < o ? -1 : o < e ? 1 : 0
            })
        }
    };
! function () {
    var n = $(".index-search").find("form"),
        e = n.find("input"),
        a = n.find("button");
    e.on("keydown", function (a) {
        13 === a.keyCode && e.val() && n.submit()
    }), a.click(function () {
        if (!e.val()) return !1
    })
}(),
function (c, s) {
    function a() {
        if (!(600 < c.width())) {
            var n, a = $(".main-filter"),
                e = a.find(".place .filter-title"),
                o = a.find(".role .filter-title"),
                i = a.find(".experience .filter-title"),
                t = {},
                r = a.find("a");
            isFixed = !1, $btn = a.find(".mobile-filter button"), isFixed = !!s.hasClass("filter-fixed"), r.unbind().click(function () {
                return !1
            }), $btn.click(function () {}), $.each([e, o, i], function () {
                var a = this;
                this.parent().find("ul").each(function () {
                    var n = $(this),
                        e = n.find("li");
                    e.on("touchend", function () {
                        var a = $(this);
                        a.hasClass("active") || (e.removeClass("active"), a.addClass("active"), t[n] = a.find("a").attr("link"))
                    })
                }), this.unbind().on("click", function () {
                    if (isFixed || s.addClass("filter-fixed"), a.hasClass("active")) return s.removeClass("filter-fixed"), void a.removeClass("active");
                    n && (n.removeClass("active"), n.parent().find(".filter-context").removeClass("active")), (n = a).addClass("active"), a.parent().find(".filter-context").addClass("active")
                })
            })
        }
    }
    a(), c.on("resize", a)
}($(window), $("body")), $(document).on("click", ".filter .more", function () {
    var a = $(this).parent();
    $(this).hasClass("active") ? (a.removeClass("show"), $(this).removeClass("active")) : (a.addClass("show"), $(this).addClass("active"))
});
var company = new Company;
$(".company").each(function () {
    var a = $(this).attr("data-company"),
        n = company.famous_companys(a);
    if (0 < n.length) {
        $(this).find(".company-tag").remove();
        for (var e = 0; e < n.length; e++) {
            var o = n[e],
                i = o.company_name,
                t = o.company_color,
                r = "<span class='company-tag normal' style='border-color:" + o.company_border_color + ";color:" + t + "'>" + i + "</span>";
            $(this).append(r)
        }
    }
}), $(".engineer-info .job>b").each(function () {
    var a = $(this).text();
    $(this).text(a.toUpperCase())
});