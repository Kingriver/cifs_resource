



    //判断是否为微信
    is_weixin();
    function is_weixin() {
        var ua = window.navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
            $(".wechat_login").attr("href", "https://shixian.com/users/auth/wechat");
            $(".weibo_login").hide();
            $(".github_login").hide();
        } else {
            $(".wechat_login").attr("href", "https://shixian.com/users/auth/open_wechat")
        }
    }
 




    // $("#wx-activity-popover").popover({
    //     html: !0,
    //     content: function () {
    //         return '<img alt="Sx activity" class="sx_activity" src="https://cdn.shixian.com/assets/shixian-qr-code-1172ea9fd974a9901cb4ea6a5c826cb7f16aeaed0cce6f7815b292428b1ae7ca.png" />'
    //     },
    //     trigger: "hover",
    //     placement: "top"
    // });




// 百度统计等 

    // var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    // document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F25e3b17ddf2b132427768bfebf751a76' type='text/javascript'%3E%3C/script%3E"));


//  growingio

    // var _vds = _vds || [];
    // window._vds = _vds;
    // (function () {
    //     _vds.push(['setAccountId', 'acf6ac3446a1dcb0']);
    //     (function () {
    //         var vds = document.createElement('script');
    //         vds.type = 'text/javascript';
    //         vds.async = true;
    //         vds.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'dn-growing.qbox.me/vds.js';
    //         var s = document.getElementsByTagName('script')[0];
    //         s.parentNode.insertBefore(vds, s);
    //     })();
    // })();
